#include <Eigen/Dense>
#include <vector>
#include <queue>
#include <unordered_map>

using namespace std;
using namespace Eigen;

struct Node {
    Vector3d position;
    double gScore;
    double fScore;
    Node* cameFrom;

    Node(Vector3d position): position(position), gScore(INFINITY), fScore(INFINITY), cameFrom(nullptr) {}
};

struct CompareFScore {
    bool operator()(Node* n1, Node* n2) {
        return n1->fScore > n2->fScore;
    }
};

double heuristic_cost_estimate(Vector3d start, Vector3d goal) {
    return (goal - start).norm();
}

vector<Vector3d> reconstruct_path(Node* current) {
    vector<Vector3d> total_path;
    while (current != nullptr) {
        total_path.push_back(current->position);
        current = current->cameFrom;
    }
    reverse(total_path.begin(), total_path.end());
    return total_path;
}

vector<Vector3d> AStar(Vector3d start, Vector3d goal, vector<Obstacle>& obstacles) {
    unordered_map<Vector3d, Node*, hash<Vector3d>> nodes;
    priority_queue<Node*, vector<Node*>, CompareFScore> openSet;

    Node* startNode = new Node(start);
    startNode->gScore = 0;
    startNode->fScore = heuristic_cost_estimate(start, goal);
    nodes[start] = startNode;
    openSet.push(startNode);

    while (!openSet.empty()) {
        Node* current = openSet.top();
        openSet.pop();

        if (current->position == goal) {
            return reconstruct_path(current);
        }

        // Generate neighbors
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -1; dz <= 1; dz++) {
                    Vector3d neighborPos = current->position + Vector3d(dx, dy, dz);

                    // Check if neighbor is in an obstacle
                    bool inObstacle = false;
                    for (Obstacle& obs : obstacles) {
                        if (obs.contains(neighborPos)) {
                            inObstacle = true;
                            break;
                        }
                    }
                    if (inObstacle) continue;

                    // Create neighbor node
                    Node* neighbor;
                    if (nodes.find(neighborPos) == nodes.end()) {
                        neighbor = new Node(neighborPos);
                        nodes[neighborPos] = neighbor;
                    } else {
                        neighbor = nodes[neighborPos];
                    }

                    // Calculate new g score
                    double tentative_gScore = current->gScore + (neighborPos - current->position).norm();
                    if (tentative_gScore < neighbor->gScore) {
                        neighbor->cameFrom = current;
                        neighbor->gScore = tentative_gScore;
                        neighbor->fScore = tentative_gScore + heuristic_cost_estimate(neighborPos, goal);
                        openSet.push(neighbor);
                    }
                }
            }
        }
    }

    // No path found
    return vector<Vector3d>();
}